﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Chzzk_chat_logger
{
    public  class GetChannel
    {
        public string streamer { get; set; }
        public string AUT { get; set; }
        public string SES { get; set; }

        public string User_ID_Hash;
    }

    public class methodChannel
    {
        public void get_userIDHash()
        {

        }

        public async Task<string> FetchUserIdHashAsync(Dictionary<string, string> cookies)
         {
            try
            {
                using var client = new HttpClient();
                var cookieString = string.Join("; ", cookies.Select(kv => $"{kv.Key}={kv.Value}"));
                client.DefaultRequestHeaders.Add("Cookie", cookieString);

                var responseString = await client.GetStringAsync("https://comm-api.game.naver.com/nng_main/v1/user/getUserStatus");
                using var jsonDoc = JsonDocument.Parse(responseString);
                return jsonDoc.RootElement.GetProperty("content").GetProperty("userIdHash").GetString();
            }
            catch
            {
                throw new ArgumentException($"잘못된 입력값: {cookies}");
            }
         }


        public async Task<(string, string)> FetchAccessTokenAsync(string chatChannelId, Dictionary<string, string> cookies)
        {
            var url = $"https://comm-api.game.naver.com/nng_main/v1/chats/access-token?channelId={chatChannelId}&chatType=STREAMING";
            try
            {
                using var client = new HttpClient();
                var cookieString = string.Join("; ", cookies.Select(kv => $"{kv.Key}={kv.Value}"));
                client.DefaultRequestHeaders.Add("Cookie", cookieString);

                var responseString = await client.GetStringAsync(url);
                using var jsonDoc = JsonDocument.Parse(responseString);
                var accessToken = jsonDoc.RootElement.GetProperty("content").GetProperty("accessToken").GetString();
                var extraToken = jsonDoc.RootElement.GetProperty("content").GetProperty("extraToken").GetString();

                return (accessToken, extraToken);
            }
            catch
            {
                throw new ArgumentException($"잘못된 입력값: {chatChannelId}, {cookies}");
            }
        }


        public async Task<string> FetchChannelNameAsync(string streamer)
        {
            var url = $"https://api.chzzk.naver.com/service/v1/channels/{streamer}";
            try
            {
                using var client = new HttpClient();
                var responseString = await client.GetStringAsync(url);
                using var jsonDoc = JsonDocument.Parse(responseString);
                return jsonDoc.RootElement.GetProperty("content").GetProperty("channelName").GetString();
            }
            catch
            {
                throw new ArgumentException($"잘못된 입력값: {streamer}");
            }
        }


        public async Task<string> FetchChatChannelIdAsync(string streamer)
        {
            var url = $"https://api.chzzk.naver.com/polling/v2/channels/{streamer}/live-status";
            try
            {
                using var client = new HttpClient();
                 var responseString = await client.GetStringAsync(url);
                using var jsonDoc = JsonDocument.Parse(responseString);
                return jsonDoc.RootElement.GetProperty("content").GetProperty("chatChannelId").GetString();
            }
            catch
            {
                throw new ArgumentException($"잘못된 입력값: {streamer}");
            }
        }
    }

    
}
