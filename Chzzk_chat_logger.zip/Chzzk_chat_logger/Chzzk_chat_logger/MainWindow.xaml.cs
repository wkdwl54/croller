﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


using System;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using Hardcodet.Wpf.TaskbarNotification;



namespace Chzzk_chat_logger
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        ChzzChat ch;
        LogManager log = new LogManager();

        Dictionary<string,string> cookies;
       public static bool IsLive = false;
        DateTime loggingtime;
        private Timer m_ThreadTimer = null;

        
        public MainWindow()
        {
            InitializeComponent();

            tb_AUT.Text = Properties.Settings.Default.AUT;
            tb_SES.Text = Properties.Settings.Default.SES;
            tb_streamer.Text = Properties.Settings.Default.STREAMER;
            m_ThreadTimer = new Timer(businessthread);
            m_ThreadTimer.Change(0, Timeout.Infinite);
            IsLive = true;



        }
        private int timerLoopCount = 0;
        public void businessthread(object obj)
        {
            try
            {
                if(IsLive== true)
                {
                    timerLoopCount = 0;
                    DateTime nowtime = DateTime.Now;

                    TimeSpan timeDifference = nowtime - loggingtime;
                    if (timeDifference.TotalSeconds >= 60)
                    {
                        loggingtime = DateTime.Now;

                        if(ch!=null)
                        ch.CloseConnectionAsync();
                        ch = new ChzzChat(tb_streamer.Text, cookies, this);



                    }
                }
              
            }
            catch
            {

            }

            finally
            {
                if (IsLive == true) m_ThreadTimer.Change(20, Timeout.Infinite);
            }
            
        }

        public void Writelog(string a)
        {
            this.Dispatcher.BeginInvoke(DispatcherPriority.Send, new Action(delegate
            {



                rtb.ScrollToEnd();

                int lineCount = rtb.Document.Blocks.Count;

                if (lineCount > 200)
                {
                    rtb.Document.Blocks.Remove(rtb.Document.Blocks.FirstBlock);
                }
                rtb.AppendText(a + Environment.NewLine);

                log.WriteLog(a);

                loggingtime= DateTime.Now;
            }));


        }

        private void btn_logging_Click(object sender, RoutedEventArgs e)
        {

            if(tb_AUT.Text == "" || tb_SES.Text == "" || tb_streamer.Text == "")
            {
                MessageBox.Show("Check Text Box");
            }
            else
            {
                Properties.Settings.Default.AUT = tb_AUT.Text;
                Properties.Settings.Default.SES = tb_SES.Text;
                Properties.Settings.Default.STREAMER = tb_streamer.Text;
                Properties.Settings.Default.Save();

                cookies = new Dictionary<string, string>
                {
                    //{ "NID_AUT", "bX8SyJq0366GaPLjZ/MW0MaN10xEPeznfXoRLISqAMyEvsK+PaytkeSjiqaWYszJ" },
                    //{ "NID_SES", "AAABnB2ReUYxTMr6uG3LO7clGnvovYxogQwWWKDyOYVZOl6eJpxA+wS5yoqoWuUdT34dooozWnQG93w3PIs68PYlUMx3DqsGy67qdaahCtAVw1E/6sfat+tB0Vvp9UedcrMBtO2hbJ3t9umELSswoTa9VLcBZQaeU56ie5Yc2OXbUJL1RsWnMzmb9sawFbAiAqAjFGcni2XyPqvPY6Fs1MID6WSfUEc75QwpKOWoAwR1rUAFv9wYudcSCXexWZFHMXgzDvxbWd9nd8w7s878ruxbtKk90FUld7lOy7q5xe+MQnceqDbjr+XZfi1iGzG8mvKUu8Zfsezv2QkbcLyQge1WcysWu9pdq3VVjPokbxbCqj87Z8fE5i6gzI6a1LaN2bH3JI2PavB41nmU2ZCOVTBVZXBvOfpyTkd7T/n6xew0B8SemqvQQ+xGZ53WETFNysa9UC9pAZxq2/L4Ac4wOd+CmRp+Ah77/BoUeRfhxBBYDmdArtL+hU98UBwxqGuaEzJs8NEOA+9Zo8CZoJz22j/cr8vxhLqzTksOGrqskB97WJVl" }

                    { "NID_AUT", tb_AUT.Text },
                    { "NID_SES", tb_SES.Text }

                };

                if(ch==null)   ch= new ChzzChat(tb_streamer.Text, cookies, this);


            }


            


        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
          
            if (WindowState == WindowState.Minimized)
            {
                this.Hide(); // 윈도우 숨기기

                // TaskbarIcon을 통해 액세스
                var notifyIcon = (TaskbarIcon)this.FindResource("MyNotifyIcon");
                notifyIcon.Visibility = Visibility.Visible;
            }
        }

        private void TaskbarIcon_TrayMouseDoubleClick(object sender, RoutedEventArgs e)
        {
            this.Show();
            WindowState = WindowState.Normal;
        }

        private void btn_logging_Copy_Click(object sender, RoutedEventArgs e)
        {
            
           
            
        }
    }
}
