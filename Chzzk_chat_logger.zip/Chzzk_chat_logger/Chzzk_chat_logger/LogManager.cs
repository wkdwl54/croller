﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chzzk_chat_logger
{
    public class LogManager
    {
        private readonly string logDirectoryPath;

        public LogManager()
        {
            // 프로그램 실행 디렉토리 내의 LOG 폴더 경로를 설정합니다.
            logDirectoryPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LOG");
            EnsureLogDirectoryExists();
        }

        private void EnsureLogDirectoryExists()
        {
            // LOG 폴더가 존재하지 않으면 생성합니다.
            if (!Directory.Exists(logDirectoryPath))
            {
                Directory.CreateDirectory(logDirectoryPath);
                Console.WriteLine($"LOG directory created at {logDirectoryPath}");
            }
        }


        public void WriteLog(string message)
        {
            // 현재 날짜를 기반으로 로그 파일 이름을 설정합니다.
            string logFileName = DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            string logFilePath = Path.Combine(logDirectoryPath, logFileName);

            // 로그 메시지에 현재 시간을 추가합니다.
            string logMessage = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} - {message}\n";

            // 로그 파일에 메시지를 추가합니다. 파일이 없으면 새로 생성됩니다.
            File.AppendAllText(logFilePath, logMessage);
        }
    }
}
