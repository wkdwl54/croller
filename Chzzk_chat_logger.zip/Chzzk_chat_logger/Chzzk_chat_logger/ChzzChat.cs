﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Net.Sockets;
using System.Windows.Media;
using System.Windows;

namespace Chzzk_chat_logger
{
    public class ChzzChat
    {
        methodChannel mc = new methodChannel();
        private ClientWebSocket sock;
        private string streamer;
        private Dictionary<string, string> cookies;
        //private ILogger logger; // ILogger는 예시용 인터페이스입니다. 실제 로깅 구현에 맞게 수정해야 합니다.
        public static bool running = false;
        private string Sid = null;
        private string userIdHash;
        private string chatChannelId;
        private string channelName;
        private (string accessToken, string extraToken) tokens;
        MainWindow Main;
        private CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        public ChzzChat(string streamer, Dictionary<string, string> cookies, MainWindow main)
        {
            this.streamer = streamer;
            this.cookies = cookies;
            //     this.logger = logger;
            sock = new ClientWebSocket();
            Main= main;
            InitializeAsync(cancellationTokenSource.Token);
            running = true;
          
        }

        public async Task CloseConnectionAsync()
        {
            running = false;
            if (sock.State == WebSocketState.Open)
            {
                running = false;
                cancellationTokenSource.Cancel();
                // 여기에서 필요한 추가 정리 작업을 수행할 수 있습니다.
                InitializeAsync(cancellationTokenSource.Token);
            }


                 

    }

        public async Task InitializeAsync(CancellationToken tk)
        {
            userIdHash = await mc.FetchUserIdHashAsync(cookies);
            chatChannelId = await mc.FetchChatChannelIdAsync(streamer);
            channelName = await mc.FetchChannelNameAsync(streamer);
            tokens = await mc.FetchAccessTokenAsync(chatChannelId, cookies);
            await ConnectAsync(cancellationTokenSource.Token);
            await ReceiveMessagesAsync(cancellationTokenSource.Token);


        }


        public async Task ConnectAsync(CancellationToken tk)
        {
            try
            {
                await sock.ConnectAsync(new Uri("wss://kr-ss1.chat.naver.com/chat"), cancellationTokenSource.Token);
                Console.Write($"{chatChannelId} 채팅창에 연결 중 .");

                var defaultDict = new
                {
                    
                };

                var sendDict = new
                {
                    ver = "2",
                    svcid = "game",
                    cid = chatChannelId,
                    cmd = 100,
                    tid = 1,
                    bdy = new
                    {
                        uid = userIdHash,
                        devType = 2001,
                        accTkn = tokens.accessToken,
                        auth = "SEND"
                    }
                };

               




                await SendMessageAsync(sendDict);
                var sockResponse = await ReceiveMessageAsync();
                Sid = sockResponse.GetProperty("bdy").GetProperty("sid").GetString();
                Console.Write($"\r{chatChannelId} 채팅창에 연결 중 ..");

                

                var sendDict2 = new
                {
                    ver = "2",
                    svcid = "game",
                    cid = chatChannelId,
                    cmd = 5101,
                    tid = 1,
                   
                    bdy = new
                    {

                      recentMessageCount = 50
                    }



                };

                await SendMessageAsync(sendDict2);
                Main.StreamerNick.Content = $"\r{channelName} 채팅창에 연결 중 ...";

                Main.Title = $"\r{channelName} 채팅창에 크롤링";
                if (sock.State == WebSocketState.Open)
                {
                    Main.ConnectionStatus.Content = "Start Logging";
                    Main.ConnectionStatus.Foreground = Brushes.Green;
                    Main.StreamerNick.Content = channelName;
                }
                else
                {
                    throw new Exception("오류 발생");

                    Main.ConnectionStatus.Content = "FAIL Logging";
                    Main.ConnectionStatus.Foreground = Brushes.Red;

                }
            }
            catch (Exception ex)
            {
                 Console.WriteLine($"WebSocket 연결 오류: {ex.Message}");
                CloseConnectionAsync();

                Main.ConnectionStatus.Content = "FAIL Logging";
                Main.ConnectionStatus.Foreground = Brushes.Red;
            }
        }

        
        private async Task ReceiveMessagesAsync(CancellationToken tk)
        {
            var buffer = new byte[1024 * 4]; // Adjust buffer size as needed

            while (running)
            {
                try
                {
                    WebSocketReceiveResult result;
                    string rawMessage = string.Empty;

                    do
                    {
                        result = await sock.ReceiveAsync(new ArraySegment<byte>(buffer), cancellationTokenSource.Token);
                        rawMessage += Encoding.UTF8.GetString(buffer, 0, result.Count);
                    } while (!result.EndOfMessage);

                    var messageJson = JsonDocument.Parse(rawMessage);
                    var chatCmd = messageJson.RootElement.GetProperty("cmd").GetInt32();

                    // Assuming CHZZK_CHAT_CMD is accessible and contains the command strings
                    if (chatCmd == 0)
                    {
                        await SendMessageAsync(new
                        {
                            ver = "2",
                            cmd = 10000
                        });
                        continue;
                    }

                    if (chatCmd != 93101 && chatCmd != 93102)
                    {
                        continue;
                    }

                    foreach (var chatData in messageJson.RootElement.GetProperty("bdy").EnumerateArray())
                    {
                        string nickname = "익명의 후원자"; // Default nickname for anonymous users

                        if (chatData.GetProperty("uid").GetString() != "anonymous")
                        {
                            try
                            {
                                var profileData = JsonDocument.Parse(chatData.GetProperty("profile").GetString());
                                nickname = profileData.RootElement.GetProperty("nickname").GetString();
                            }
                            catch
                            {
                                continue; // Skip on parsing failure
                            }
                        }

                        var now = DateTimeOffset.FromUnixTimeMilliseconds(chatData.GetProperty("msgTime").GetInt64()).DateTime;
                        var formattedTime = now.ToString("yyyy-MM-dd HH:mm:ss");

                        // logger.Info($"[{formattedTime}] {nickname} : {chatData.GetProperty("msg").GetString()}");
                        Console.WriteLine($"[{formattedTime}] {nickname} : {chatData.GetProperty("msg").GetString()}");

                        //Main.rtb.AppendText(($"[{formattedTime}] {nickname} : {chatData.GetProperty("msg").GetString()}"));

                        Main.Writelog($"[{formattedTime}] {nickname} : {chatData.GetProperty("msg").GetString()}");
                    }
                }
                catch (WebSocketException)
                {
                    // Attempt to reconnect or handle the exception as needed
                  //  await ConnectAsync();
                }
                catch(Exception ex)
                {
                    // General exception handling, possibly logging the error
                    
                }
            }
        }



        private async Task SendMessageAsync(object message)
        {
            var messageString = JsonSerializer.Serialize(message);
            var buffer = Encoding.UTF8.GetBytes(messageString);
            await sock.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
        }

        private async Task<JsonElement> ReceiveMessageAsync()
        {
            var buffer = new byte[1024 * 4];
            var result = await sock.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            var messageString = Encoding.UTF8.GetString(buffer, 0, result.Count);
            return JsonDocument.Parse(messageString).RootElement;
        }

    }
}
